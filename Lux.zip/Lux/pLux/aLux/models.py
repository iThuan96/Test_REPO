from django.db import models

# Create your models here.

class Users(models.Model):
    name_U = models.CharField(max_length = 50)
    desired_brightness = models.FloatField()

    class Meta:
        db_table = 'tbl_users'
        managed = True

    def __str__(self):
        return self.name_U
    
class Lights(models.Model):
    name_L = models.CharField(max_length = 50)
    value = models.FloatField()

    class Meta:
        db_table = 'tbl_lights'
        managed = True
    
    def __str__(self):
        return self.name_L + str(self.value)
    
class Room(models.Model):
    type = models.CharField(max_length = 50)
    class Meta:
        db_table = 'tbl_Room'
        managed = True
    def __str__(self):
        return str(self.pk) + self.type

class RoomLight(models.Model):
    id_R = models.ForeignKey(Room, on_delete=models.PROTECT, blank=True, null=True)
    id_L = models.ForeignKey(Lights, on_delete=models.PROTECT, blank=True, null=True)
    number_light = models.FloatField()
    class Meta:
        db_table = 'tbl_RoomLight'
        managed = True
    def __str__(self):
        return str(self.id_R) + str(self.id_L)
    