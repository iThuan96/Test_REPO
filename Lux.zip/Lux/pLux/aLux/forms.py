from django import forms
from .models import *

class userForm(forms.ModelForm):
    class Meta:
        model = Users
        fields = ('name_U', 'desired_brightness')
        widgets = {
            'name_U' : forms.TextInput(attrs={'class':'form-control'}),
            'desired_brightness' : forms.TextInput(attrs={'class':'form-control'}),
            
        }

