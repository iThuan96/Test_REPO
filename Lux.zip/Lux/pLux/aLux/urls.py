from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('light', views.light, name='light'),
    path('user', views.user, name='user'),
]
