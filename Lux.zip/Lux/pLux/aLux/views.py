from django.shortcuts import redirect, render
from django.db.models import Q
from .models import *
from .forms import *

# Create your views here.
def home(request):
    return render(request, 'lux/home.html')

# LIGHT 
def light(request):
    if request.method == 'POST':
        lights = Lights.objects.all()
        context = {'lights': lights}
        return render(request, 'lux/light.html', context)
    else:
        lights = Lights.objects.all()
        context = {'lights': lights}
    return render(request, 'lux/light.html', context)

# USER 
def user(request):
    user = Users.objects.all()
    if request.method == 'POST':
        form = userForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/')
            except:
                pass
    else:
        form = userForm()
    return render(request, 'lux/user.html', {'form':form, 'user':user})


